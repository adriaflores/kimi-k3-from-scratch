# Kimi K3 — verified lightweight evidence (M7 + M8 + M9.3 + M9.4)

Original evidence provided by the experiment owner; audit performed on the supplied archived `run.json` / `metrics.jsonl`, receipts, prepared-data metadata and M9.3 per-window CSV. The raw source archives are deliberately **not** repackaged. Exact SHA-256 hashes of all source inputs are in `full_training_evidence_audit.json`.

- M7 pilot: steps 0–2,442; 80,019,456 processed tokens; 146 clipped updates; zero skipped attempts. Monitoring loss: train first 10.91515, final 3.99333; fixed-prefix validation first 7.89791, final 4.10031.
- M8 continuation: steps 2,442–183,106 in three sessions; 180,664 successful updates; 2,294 clipped; zero skipped attempts. Training-window final loss 3.18165; monitoring-prefix final validation loss 3.18249.
- Overall: 183,106 successful optimizer updates; 6,000,017,408 processed token positions; zero logged skipped attempts; 2,440 clipped updates in total (1.33%). **These are processed positions, not necessarily unique tokens.**
- M9.3: 64 × 1,024 fixed validation windows scored once each; NLL 3.05095815; perplexity 21.13558581; top-1 42.2653%. This evaluation uses FP32 reference chunkwise KDA and must not be compared directly with training BF16/fused monitoring loss.

The PNG is split into two vertically stacked panels because the 80M-token pilot is too short to distinguish on a linear 0–6B scale. Training-line smoothing on the continuation uses the most recent 32 logged windows, weighted by optimizer updates; the CSV retains every original window statistic. Validation curves repeatedly score the same fixed prefix and do not establish independent generalization.

**Evidence boundaries:** the checkpoint hashes are verified *against historical receipts*, not by rehashing checkpoint bytes. Git commit/dirty information in run manifests is absent. M7 included a 35-file source checksum inventory and M7.5 recorded verification of 35 files; full byte-level source provenance through M8 is not established in these archives. The dataset shard contents and M9.3 logits were not rerun; the M9.3 aggregate was independently recomputed from the provided CSV.

To reproduce locally, install Python 3.12+, optional `matplotlib`, and execute `audit_full_training.py --help` for the required source arguments. This script reads the source files without modifying them and writes a JSON audit, window-level CSVs and an optional figure.


## M9.4: fixed qualitative evaluation

The original user-supplied `fixed(1).zip` was CRC-tested. All **12 case JSON receipts** exactly match the cases in the original `m94_results.json`, corresponding CSV records, and the unedited continuation readout. The mean repeat-trigram and unique-token ratios were **recomputed from the 48 token IDs of every case**:

| Measure | Greedy (6) | Sample (6) |
| --- | ---: | ---: |
| Mean repeated-trigram fraction | 32.61% | 6.16% |
| Mean unique-token ratio | 48.61% | 65.28% |
| Cases with >30% repeated trigrams | 5/6 | 0/6 |

Exactly 576 tokens were generated, with zero EOS events under the 48-token cap. The original fixed-generation mode was **FP32 PyTorch chunkwise**, without cache, using six preselected English prompts. Sampling used seed 1337, temperature 1, top-k 50 and top-p 0.95. It increases diversity in these samples without establishing increased coherence or factual reliability. The original records have `human_rating=NOT_YET_COLLECTED`; no human numerical scores are invented. The full originals are preserved verbatim in `M94_FIXED_GENERATIONS_UNEDITED.md`.

`m94_evidence_audit.json` contains the archive SHA-256, verified run identity, all per-case metrics, and limitations. Run `python audit_m94_qualitative.py --archive /path/to/fixed.zip --output /path/to/result.json` to recompute it using only the Python standard library. The audit verifies **record consistency**; it does **not** rerun the model, rehash the checkpoint bytes, or prove numerical equivalence to the BF16/fused training kernels.

**Publishable scope:** a reduced-scale architectural/research-engineering implementation, a full processed-token training run with audited telemetry and recovery, an independent fixed-window evaluation from the held-out *validation split*, and a small transparent qualitative characterization. Avoid capability-comparison, general language quality, or full frozen-source-provenance claims.

`RESULTS_README_DRAFT.md` is a short optional README section for manual review. Do not treat its presence as approval to edit or publish the repository.

# M9.4 — Fixed qualitative evaluation

**Status:** PASS_FIXED_QUALITATIVE

**Method:** 6 pre-registered prompts × greedy + seeded sampling, 48 tokens maximum,
FP32, chunkwise PyTorch, no cache, 1024-token training-length context cap.

**Limitations:** samples are descriptive; no automated human-coherence score,
not Chat/Instruct, BF16/fused equivalence unestablished.

## All generated continuations (unedited)

### story_greedy — narrative (greedy)

**Prompt**

```text
Once upon a time, in a small village
```

**Continuation**

```text
, there lived a man named Ahab. He was a man of great strength and courage, and he was a man of honor. He was a man of honor, and he was a man of honor. He was a man of honor
```

Tokens: 48 | EOS: False | Repeat trigrams: 0.435

### story_sample — narrative (sample)

**Prompt**

```text
Once upon a time, in a small village
```

**Continuation**

```text
, there stood a woman, her name being Kola, a woman in uniform, in a round-rigged suit, in a white robe and a white cloak.
A young woman's costume, of gold-roled or j
```

Tokens: 48 | EOS: False | Repeat trigrams: 0.022

### science_greedy — scientific prose (greedy)

**Prompt**

```text
The results of the experiment showed that
```

**Continuation**

```text
 the number of people who were able to identify the location of a person’s body was significantly higher than the number of people who were able to identify the location of a person’s body.
The results of the experiment also showed that
```

Tokens: 48 | EOS: False | Repeat trigrams: 0.326

### science_sample — scientific prose (sample)

**Prompt**

```text
The results of the experiment showed that
```

**Continuation**

```text
 the number of birds released was only 20,000 in comparison to birds released 25000 miles apart. The numbers of birds released increased, whereas the number of birds released was much smaller. However, the
```

Tokens: 48 | EOS: False | Repeat trigrams: 0.130

### explain_greedy — expository prose (greedy)

**Prompt**

```text
The main advantage of solar energy is
```

**Continuation**

```text
 that it is a clean and renewable energy source. Solar energy is a clean and renewable energy source because it does not produce any greenhouse gases or pollution. Solar energy is also a clean and renewable energy source because it does not produce any greenhouse gases
```

Tokens: 48 | EOS: False | Repeat trigrams: 0.413

### explain_sample — expository prose (sample)

**Prompt**

```text
The main advantage of solar energy is
```

**Continuation**

```text
 that it does not have to be stored. Solar energy is clean, but in order to store it it has to be stored and it is not economical to store a lot of energy.
Because solar energy is clean it is used in power
```

Tokens: 48 | EOS: False | Repeat trigrams: 0.043

### history_greedy — historical prose (greedy)

**Prompt**

```text
During the nineteenth century, many cities
```

**Continuation**

```text
 in the United States adopted the “urban renewal” philosophy. This philosophy emphasized the importance of the neighborhood in the city and the need for a large, well-maintained neighborhood.
The “urban renewal” philosophy was also popular in the
```

Tokens: 48 | EOS: False | Repeat trigrams: 0.065

### history_sample — historical prose (sample)

**Prompt**

```text
During the nineteenth century, many cities
```

**Continuation**

```text
 of the East and the West started to invest in and develop the field of engineering. Many of these projects brought about significant changes in the way people perceived and used engineering and technology.
The Civil War in America began during the Reconstruction Era.
```

Tokens: 48 | EOS: False | Repeat trigrams: 0.000

### narrative2_greedy — fiction continuation (greedy)

**Prompt**

```text
When Alice opened the door, she saw
```

**Continuation**

```text
 a huge, white, red, and green ball floating in the air.
“It’s a giant, giant,” she said. “It’s a giant, giant!”
“It’s a giant, giant!”

```

Tokens: 48 | EOS: False | Repeat trigrams: 0.304

### narrative2_sample — fiction continuation (sample)

**Prompt**

```text
When Alice opened the door, she saw
```

**Continuation**

```text
 a huge tree grow from her window. It was made of an iron, stone, bronze, and gold.
When Alice got home, she didn’t find her little boy. He was still too young to go to school and did
```

Tokens: 48 | EOS: False | Repeat trigrams: 0.000

### process_greedy — procedural prose (greedy)

**Prompt**

```text
To prepare the mixture, first add
```

**Continuation**

```text
 1 teaspoon of salt to 1 quart of water. Then add 1 teaspoon of the mixture to 1 quart of water. Finally, add 1 teaspoon of the mixture to 1 quart of water.
- When the mixture
```

Tokens: 48 | EOS: False | Repeat trigrams: 0.413

### process_sample — procedural prose (sample)

**Prompt**

```text
To prepare the mixture, first add
```

**Continuation**

```text
 1 tsp of sodium lauryl sulfate to 100ml of water until it is 95-98.5% liquid.
Second, add 1 tsp of concentrated sodium lauryl sulfate to 1
```

Tokens: 48 | EOS: False | Repeat trigrams: 0.174


#!/usr/bin/env python3
"""Read-only, source-linked audit of the Kimi K3 M7 pilot -> M8 pretraining.

Only stdlib required for JSON/CSV outputs. Optional matplotlib for figure.
The script does not open checkpoint tensors, contact GitHub, or change the source ZIPs.

Example:
python audit_full_training.py --m7 m73_results.zip --m7-receipt final_receipt.json \
  --m75 m75_resume_gate.zip --m8 m8_final_evidence.zip \
  --m8-receipt final_local_verification.json --metadata metadata.json \
  --m93 m93_results.json --per-window per_window.csv --out output_directory
"""
import argparse, collections, csv, hashlib, io, json, math, zipfile
from pathlib import Path

TOKENS = 32768

def insist(ok, why):
    if not ok:
        raise AssertionError(why)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def filehash(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def archive(path):
    with zipfile.ZipFile(path) as z:
        insist(z.testzip() is None, f'Bad ZIP CRC in {path}')
        return {name: z.read(name) for name in z.namelist()}

def j(data):
    return json.loads(data)

def log(data):
    return [j(line) for line in data.splitlines() if line.strip()]

def verify_run(run, events, name, starts):
    insist(all(e['run_id'] == run['run_id'] for e in events), f'{name}: run ID mismatch')
    insist(all(events[i]['timestamp'] <= events[i+1]['timestamp'] for i in range(len(events)-1)), f'{name}: timestamps not monotonic')
    insist(all(e['tokens_seen'] == e['step'] * TOKENS for e in events), f'{name}: token counter mismatch')
    insist(len(run['sessions']) == len(starts), f'{name}: unexpected sessions')
    all_train, all_val, session_info = [], [], []
    for i, session in enumerate(run['sessions']):
        sid = session['session_id']
        segment = [e for e in events if e['session_id'] == sid]
        insist(segment and segment[0]['event'] == 'session_start', f'{name}: missing session_start')
        start = session['start_state']['step']
        insist(start == starts[i] == segment[0]['step'], f'{name}: unexpected start')
        if i: insist(start == session_info[-1]['end_step'], f'{name}: disconnected sessions')
        previous = start
        rows = [e for e in segment if e['event'] == 'train']
        for e in rows:
            insist(e['step'] - previous == e['updates'], f'{name}: missing/duplicated train updates near step {e["step"]}')
            insist(e['tokens'] == e['updates'] * TOKENS, f'{name}: incorrect training window tokens')
            insist(e['attempted_updates'] == e['updates'] + e['skipped_updates_in_window'], f'{name}: inconsistent skipped updates')
            insist(math.isfinite(e['train_loss']) and math.isfinite(e['train_seconds']), f'{name}: nonfinite train stats')
            previous = e['step']
        insist(rows and previous == segment[-1]['step'], f'{name}: missing tail updates')
        clipped = sum(round(r['clipped_fraction'] * r['attempted_updates']) for r in rows)
        insist(all(abs(r['clipped_fraction']*r['attempted_updates'] - round(r['clipped_fraction']*r['attempted_updates'])) < 1e-5 for r in rows), f'{name}: inconsistent clipping count')
        session_info.append(dict(session_id=sid, start_step=start, end_step=previous,
                                 train_windows=len(rows), successful_updates=sum(r['updates'] for r in rows),
                                 attempted_updates=sum(r['attempted_updates'] for r in rows),
                                 clipped_updates=clipped,
                                 start_timestamp=segment[0]['timestamp'], end_timestamp=segment[-1]['timestamp']))
        all_train += rows
        all_val += [e for e in segment if e['event'] == 'val']
    insist(len(all_train) == sum(e['event']=='train' for e in events), f'{name}: orphan train records')
    insist(len(all_val) == sum(e['event']=='val' for e in events), f'{name}: orphan val records')
    return all_train, all_val, session_info

def monitor(phase, tr, vl):
    clipped = sum(round(r['clipped_fraction'] * r['attempted_updates']) for r in tr)
    attempted = sum(r['attempted_updates'] for r in tr)
    updates = sum(r['updates'] for r in tr)
    secs = sum(r['train_seconds'] for r in tr)
    best = min(vl,key=lambda r:r['val_loss'])
    return dict(phase=phase, train_windows=len(tr), validation_windows=len(vl),
       successful_updates=updates, attempted_updates=attempted,
       skipped_updates=attempted-updates, clipped_updates=clipped, clipped_fraction=clipped/attempted,
       nonfinite_grad_norm_events=sum(r['nonfinite_grad_norms'] for r in tr),
       qk_clipped_head_updates=sum(r['qk_clip']['clipped_head_updates'] for r in tr),
       train_loss_first_window=tr[0]['train_loss'], train_loss_final_window=tr[-1]['train_loss'],
       validation_first=vl[0]['val_loss'], validation_best={'step':best['step'],'loss':best['val_loss']},
       validation_final=vl[-1]['val_loss'], training_only_seconds=secs,
       training_only_tokens_per_second=updates*TOKENS/secs)

def write_csv(out, name, rows, cols):
    with (out/name).open('w', encoding='utf-8', newline='') as f:
        w=csv.DictWriter(f, fieldnames=cols);w.writeheader();w.writerows(rows)

def render_plot(out, tr, vl):
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return False
    # The phases have very different scales: separate panels prevent the pilot disappearing.
    bg='#090b10'; ink='#e8edf4'; blue='#8fb8ff'; amber='#f0be83'; grid='#303846'
    fig, axs=plt.subplots(2,1,figsize=(11.5,10.4),dpi=145)
    fig.patch.set_facecolor(bg)
    for ax in axs:
        ax.set_facecolor(bg)
        for sp in ax.spines.values():sp.set_color(grid)
        ax.tick_params(colors=ink,labelsize=15)
        ax.grid(alpha=.26,color=grid)
        ax.set_xlabel('Processed training tokens (billions)',color=ink,fontsize=17,labelpad=9)
        ax.set_ylabel('Logged cross-entropy (nats/token)',color=ink,fontsize=17,labelpad=9)
    for i,(phase,title,scale) in enumerate([('pilot','Pilot · 0–80M',1e9),('continuation','Continuation · 80M–6B',1e9)]):
        rows=[r for r in tr if r['phase']==phase]; vals=[r for r in vl if r['phase']==phase]
        xs=[r['tokens_seen']/scale for r in rows]
        losses=[r['loss'] for r in rows]
        if phase=='continuation':
            # Weighted moving average, number of real updates per metric window.
            smooth=[]
            for k in range(len(rows)):
                recent=rows[max(0,k-31):k+1]
                smooth.append(sum(r['loss']*r['updates'] for r in recent)/sum(r['updates'] for r in recent))
            axs[i].plot(xs,losses,color=blue,alpha=.19,lw=1.0)
            axs[i].plot(xs,smooth,color=blue,lw=2.3,label='Train · 32-window mean')
        else:
            axs[i].plot(xs,losses,color=blue,lw=2.1,label='Train · logged windows')
        axs[i].plot([v['tokens_seen']/scale for v in vals],[v['loss'] for v in vals],color=amber,lw=1.9,marker='o',markersize=2.7,label='Val · fixed prefix')
        axs[i].set_title(title,color=ink,loc='left',fontsize=19,pad=15)
        axs[i].legend(frameon=False,fontsize=15,labelcolor=ink,loc='upper right')
        if i==0:axs[i].set_xlim(0,.083)
        else:axs[i].set_xlim(0.08,6.05)
    fig.suptitle('Training monitoring · original M7 and M8 logs',color=ink,fontsize=23,y=0.985)
    fig.tight_layout(h_pad=3.5,rect=[0,0,1,0.94])
    fig.savefig(out/'training_monitoring_m7_m8.png',dpi=145,bbox_inches='tight',facecolor=bg)
    plt.close(fig)
    return True

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for v in ['m7','m7-receipt','m75','m8','m8-receipt','metadata','m93','per-window']:
        p.add_argument('--'+v,required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    z7=archive(a.m7); z75=archive(a.m75); z8=archive(a.m8)
    pilot=j(z7['trainer/run.json']); m8=j(z8['run.json']);
    tr7,vl7,s7=verify_run(pilot,log(z7['trainer/metrics.jsonl']),'M7',[0])
    tr8,vl8,s8=verify_run(m8,log(z8['metrics.jsonl']),'M8',[2442,4096,81920])
    r7=j(a.m7_receipt.read_bytes());embedded=j(z7['final_receipt.json'])
    insist(r7==embedded,'M7 receipt differs from original archive')
    insist(j(z7['summary.json'])['step']==r7['inspected']['step']==s7[-1]['end_step']==s8[0]['start_step'],'M7 step does not connect to M8')
    insist(r7['inspected']['skipped_updates']==0 and r7['inspected']['tokens_seen']==s7[-1]['end_step']*TOKENS,'Bad M7 receipt counters')
    gate=j(z75['m75_resume_receipt.json']);insist(gate['status']=='PASS' and gate['no_optimizer_updates_executed'] and z75['exit_code.txt'].strip()==b'0','M7.5 resume gate did not pass')
    insist(gate['checkpoint_path']==m8['sessions'][0]['resume_checkpoint']==r7['file'],'M7->M8 checkpoint path mismatch')
    insist(gate['checkpoint_sha256_before']==gate['checkpoint_sha256_after']==r7['sha256'],'M7 checkpoint hash mismatch')
    insist(gate['original_step']==s7[-1]['end_step'] and gate['original_tokens_seen']==r7['inspected']['tokens_seen'],'M7 checkpoint step mismatch')
    insist(gate['restored_train_position']==m8['sessions'][0]['start_state']['loaders']['train']['position'],'M8 train cursor mismatch')
    insist(gate['restored_val_position']==m8['sessions'][0]['start_state']['loaders']['val']['position'],'M8 val cursor mismatch')
    insist(gate['source_files_sha256_verified']==len(j(z7['source_manifest.json']))==35,'M7 source evidence incomplete')
    insist(sha(z7['source_manifest.json'])==j(z7['preflight.json'])['checks']['source_manifest_sha256'],'M7 source manifest digest mismatch')
    meta=j(a.metadata.read_bytes());canonical=sha(json.dumps(meta,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
    insist(filehash(a.metadata)==j(z7['recipe/pilot_contract.json'])['expected_dataset_metadata_file_sha256'],'M7 dataset raw manifest digest mismatch')
    for sess in pilot['sessions']+m8['sessions']:
        for split in ('train','val'):
            d=sess['data'][split]
            insist(d['metadata_sha256']==canonical,'data canonical digest mismatch')
            insist(d['total_tokens']==meta['splits'][split]['tokens'],'dataset token count mismatch')
            insist(d['source']==meta['source'] and d['tokenizer']==meta['tokenizer'],'dataset source/tokenizer mismatch')
    insist(pilot['sessions'][0]['model_config']==m8['sessions'][0]['model_config'],'M7/M8 model config mismatch')
    def trim_opt(o):
        cp=j(json.dumps(o))
        for g in cp['param_groups']:g.pop('lr',None)
        return cp
    insist(trim_opt(pilot['sessions'][0]['optimizer'])==trim_opt(m8['sessions'][0]['optimizer']), 'M7/M8 optimizer groups mismatch')
    changes={k:(v,m8['sessions'][0]['train_config'].get(k)) for k,v in pilot['sessions'][0]['train_config'].items() if v!=m8['sessions'][0]['train_config'].get(k)}
    insist(set(changes)=={'max_steps','log_interval','eval_interval','checkpoint_interval'}, 'Unexpected recipe changes')
    remote=j(z8['final_audit.json']); r8=j(a.m8_receipt.read_bytes())
    insist(filehash(a.m8)==r8['evidence_zip_sha256'],'M8 ZIP hash mismatch')
    insist(remote['status']==r8['status']=='PASS' and remote['final_step']==r8['step']==s8[-1]['end_step'],'M8 completion status mismatch')
    insist(remote['checkpoint_sha256']==r8['sha256'] and remote['checkpoint_bytes']==r8['bytes'],'M8 checkpoint receipt mismatch')
    insist(remote['events']==len(log(z8['metrics.jsonl'])),'M8 event count mismatch')
    assert s7[-1]['end_step']+sum(s['successful_updates'] for s in s8)==183106
    assert remote['tokens_seen']==183106*TOKENS
    m93=j(a.m93.read_bytes());rows=list(csv.DictReader(io.StringIO(a.per_window.read_text(encoding='utf-8-sig'))))
    insist(len(rows)==m93['summary']['completed_windows']==64, 'M9.3 window count mismatch')
    nll=sum(float(r['nll_sum']) for r in rows);n=sum(int(r['scored_tokens']) for r in rows);good=sum(int(r['top1_correct']) for r in rows)
    for i,row in enumerate(rows):
        insist(int(row['window_id'])==i and int(row['offset'])==1_000_000+4_800_000*i, 'M9.3 offset mismatch')
        insist(int(row['scored_tokens'])==1024,'M9.3 token count mismatch')
    insist(math.isclose(nll,m93['summary']['nll_sum'],rel_tol=1e-12) and n==m93['summary']['scored_tokens'] and math.isclose(math.exp(nll/n),m93['summary']['perplexity_same_tokenizer'],rel_tol=1e-12),'M9.3 aggregate mismatch')
    pilot_summary=monitor('pilot',tr7,vl7); m8_summary=monitor('continuation',tr8,vl8)
    merged=dict(status='PASS_FOR_SUPPLIED_SOURCE_ARTIFACTS',
      files_sha256={k:filehash(getattr(a,k.replace('-','_'))) for k in ['m7','m7-receipt','m75','m8','m8-receipt','metadata','m93','per-window']},
      dataset_metadata_sha256_canonical=canonical, source_manifest_m7={'entries':35,'sha256':sha(z7['source_manifest.json'])},
      m7=dict(run_id=pilot['run_id'],events=len(log(z7['trainer/metrics.jsonl'])),sessions=s7,monitoring=pilot_summary,
              checkpoint_step=r7['inspected']['step'],checkpoint_sha256_recorded=r7['sha256']),
      checkpoint_bridge=dict(status=gate['status'],no_updates_in_restore_gate=True,optimizer_entries=gate['optimizer_state_entries'],rng_restored=gate['rng_verified'],start_train_cursor=gate['restored_train_position'],start_val_cursor=gate['restored_val_position'],model_config_matches=True,optimizer_param_groups_match_except_lr=True,recipe_changes=changes),
      m8=dict(run_id=m8['run_id'],events=len(log(z8['metrics.jsonl'])),sessions=s8,monitoring=m8_summary,
              checkpoint_sha256_recorded=r8['sha256']),
      full=dict(total_successful_updates=pilot_summary['successful_updates']+m8_summary['successful_updates'],
                total_tokens_processed=(pilot_summary['successful_updates']+m8_summary['successful_updates'])*TOKENS,
                recorded_skipped_updates=pilot_summary['skipped_updates']+m8_summary['skipped_updates'],
                total_clipped_updates=pilot_summary['clipped_updates']+m8_summary['clipped_updates'],
                overall_clipped_fraction=(pilot_summary['clipped_updates']+m8_summary['clipped_updates'])/(pilot_summary['attempted_updates']+m8_summary['attempted_updates']),
                train_windows=len(tr7)+len(tr8),validation_windows=len(vl7)+len(vl8)),
      m93=dict(scored_tokens=n,mean_nll=nll/n,perplexity=math.exp(nll/n),top1_accuracy=good/n,recomputed_from_per_window=True),
      limitations=['Original checkpoints are not present; hashes match historical receipts but checkpoint bytes were not independently rehashed here.',
                   'Historical run.json git.commit fields are null; M7 archived source hashes and M7.5 verified source files do not establish M8 source history 35/35.',
                   'Training/validation losses are monitored on different windows; validation repeatedly uses one fixed prefix.',
                   'M9.3 evaluation aggregation reproduced from per-window records, but no model forward was rerun.'])
    (a.out/'full_training_evidence_audit.json').write_text(json.dumps(merged,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    tra=[dict(phase=phase,step=r['step'],tokens_seen=r['tokens_seen'],loss=r['train_loss'],updates=r['updates'],clipped_fraction=r['clipped_fraction'],learning_rate=r['lr'],train_seconds=r['train_seconds']) for phase,t in [('pilot',tr7),('continuation',tr8)] for r in t]
    vals=[dict(phase=phase,step=r['step'],tokens_seen=r['tokens_seen'],loss=r['val_loss']) for phase,v in [('pilot',vl7),('continuation',vl8)] for r in v]
    write_csv(a.out,'training_monitoring_m7_m8.csv',tra,['phase','step','tokens_seen','loss','updates','clipped_fraction','learning_rate','train_seconds'])
    write_csv(a.out,'validation_monitoring_m7_m8.csv',vals,['phase','step','tokens_seen','loss'])
    merged['plot_created']=render_plot(a.out,tra,vals)
    # record plot generation status in audit JSON as well.
    (a.out/'full_training_evidence_audit.json').write_text(json.dumps(merged,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'status':merged['status'],'updates':merged['full']['total_successful_updates'],'tokens':merged['full']['total_tokens_processed'],'clip':merged['full']['total_clipped_updates'],'plot':merged['plot_created']},indent=2))

if __name__=='__main__':main()

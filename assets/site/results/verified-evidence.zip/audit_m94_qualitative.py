#!/usr/bin/env python3
"""Verify M9.4 fixed-generation receipts without loading model weights.

Reads a user-owned archive without changing it. Recomputes metrics from the
48 generated token IDs in each of the 12 original case receipts and cross-checks
the accompanying CSV, summary, execution manifest and status.

Usage:
    python audit_m94_qualitative.py --archive 'fixed(1).zip' --output m94_evidence_audit.json
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import statistics
import zipfile
from pathlib import Path, PurePosixPath


def require(cond: bool, message: str) -> None:
    if not cond:
        raise ValueError(message)


def same(a: float, b: float, label: str) -> None:
    require(math.isclose(float(a), float(b), rel_tol=1e-12, abs_tol=1e-12),
            f"{label}: mismatch ({a!r} vs {b!r})")


def digest_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def decode_json(archive: zipfile.ZipFile, name: str) -> dict:
    return json.loads(archive.read(name).decode('utf-8'))


def audit(path: Path) -> dict:
    with zipfile.ZipFile(path) as z:
        require(z.testzip() is None, 'ZIP CRC/integrity check failed')
        names = z.namelist()
        require(len(set(names)) == len(names), 'Duplicated ZIP members')
        require(all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names),
                'Unsafe archive filename')
        case_files = sorted(n for n in names if n.startswith('fixed/cases/') and n.endswith('.json'))
        require(len(case_files) == 12, f'Expected 12 case JSON files, got {len(case_files)}')
        for required in ('fixed/run_manifest.json', 'fixed/m94_status.json',
                         'fixed/m94_results.json', 'fixed/generations.csv', 'fixed/M94_READOUT.md'):
            require(required in names, f'Missing {required}')
        manifest = decode_json(z, 'fixed/run_manifest.json')
        status = decode_json(z, 'fixed/m94_status.json')
        result = decode_json(z, 'fixed/m94_results.json')
        rows = list(csv.DictReader(io.StringIO(z.read('fixed/generations.csv').decode('utf-8-sig'), newline='')))
        require(len(rows) == 12, f'Expected 12 CSV records, got {len(rows)}')
        require(len(result['cases']) == 12, 'Expected 12 embedded JSON records')
        by_csv = {r['case_id']: r for r in rows}
        by_summary = {r['case_id']: r for r in result['cases']}
        require(len(by_csv) == len(by_summary) == 12, 'Duplicate case IDs')
        run_id = result['run_identity_sha256']
        require(status['status'] == result['status'] == 'PASS_FIXED_QUALITATIVE', 'Status mismatch')
        require(status['mode'] == 'FROZEN_FIXED_12', 'Unexpected evaluation mode')
        require(manifest['schema_version'] == status['schema_version'] == result['schema_version'],
                'Schema version disagreement')
        require(status['run_identity_sha256'] == run_id, 'Run ID mismatch')
        require(result['protocol_sha256'] == manifest['m94_protocol_file_sha256'], 'Protocol hash disagreement')
        require(status['case_count'] == result['case_count'] == 12, 'Case count disagreement')
        require(status['fused_parity'] == result['fused_parity'] == 'NOT_ESTABLISHED',
                'Fused-path parity claims disagree')
        require(result['human_rating'] == 'NOT_YET_COLLECTED', 'Unexpected human rating field')
        require(manifest['backend'] == 'chunkwise' and manifest['precision'] == 'fp32',
                'Unexpected evaluation backend/precision')
        require('no-cache' in manifest['generation_impl'], 'Cache policy not explicit')
        for k in ('checkpoint_size_m91', 'contract_sha256', 'protocol_sha256', 'fixed_protocol_valid'):
            require(status['checks'][k] == 'PASS', f'Status check not PASS: {k}')

        output_cases = []
        pair = {}
        per_mode = {'greedy': [], 'sample': []}
        for filename in case_files:
            case = decode_json(z, filename)
            key = case['case_id']
            require(filename == f'fixed/cases/{key}.json', f'Archive case path mismatch: {filename}')
            require(key in by_csv and key in by_summary, f'Case omitted from CSV/summary: {key}')
            require(case == by_summary[key], f'Case JSON disagrees with embedded result: {key}')
            row = by_csv[key]
            require(case['run_identity_sha256'] == run_id, f'Run identity mismatch for {key}')
            require(case['fixed_evaluation'] is True, f'Not tagged as fixed: {key}')
            require(case['backend'] == manifest['backend'] and case['precision'] == manifest['precision'],
                    f'Backend/precision mismatch: {key}')
            require(case['cache'] is False and case['max_new_tokens'] == 48,
                    f'Cache/token-limit mismatch: {key}')
            require(case['mode'] in per_mode, f'Unexpected mode: {key}')
            require(case['seed'] == 1337, f'Seed mismatch: {key}')
            if case['mode'] == 'sample':
                for k, expect in [('temperature', 1.0), ('top_k', 50), ('top_p', 0.95)]:
                    same(case[k], expect, f'{key} {k}')
            ids = case['generated_token_ids']
            require(len(ids) == case['generated_token_count'] == 48, f'Unexpected generated length: {key}')
            require(all(isinstance(x, int) and not isinstance(x, bool) for x in ids),
                    f'Non-integer token ID: {key}')
            require(case['eos_hit'] is False and 0 not in ids, f'Unexpected EOS: {key}')
            tris = [tuple(ids[j:j+3]) for j in range(len(ids) - 2)]
            repeated_trigram_fraction = (len(tris) - len(set(tris))) / len(tris)
            unique_token_ratio = len(set(ids)) / len(ids)
            same(repeated_trigram_fraction, case['repeated_trigram_fraction'], f'{key} JSON repeated trigrams')
            same(unique_token_ratio, case['unique_token_ratio'], f'{key} JSON unique tokens')
            for field in ('group', 'mode', 'prompt', 'continuation'):
                case_field = 'continuation_text' if field == 'continuation' else field
                require(row[field] == case[case_field], f'CSV {field} mismatch: {key}')
            require(case['full_text'] == case['prompt'] + case['continuation_text'],
                    f'Full text not equal to prompt + continuation: {key}')
            require(int(row['generated_tokens']) == 48 and row['eos_hit'].lower() == 'false',
                    f'CSV token count/EOS mismatch: {key}')
            require(int(row['seed']) == case['seed'], f'CSV seed mismatch: {key}')
            same(repeated_trigram_fraction, row['repeated_trigram_fraction'], f'{key} CSV repeated trigrams')
            same(unique_token_ratio, row['unique_token_ratio'], f'{key} CSV unique tokens')
            same(case['seconds_generation'], row['seconds'], f'{key} duration')
            cat = key.removesuffix('_greedy').removesuffix('_sample')
            pair.setdefault(cat, {})[case['mode']] = case['prompt']
            per_mode[case['mode']].append((repeated_trigram_fraction, unique_token_ratio))
            output_cases.append({'case_id': key, 'group': case['group'], 'mode': case['mode'],
                                 'prompt': case['prompt'], 'generated_tokens': len(ids),
                                 'eos_hit': case['eos_hit'],
                                 'repeated_trigram_fraction': repeated_trigram_fraction,
                                 'unique_token_ratio': unique_token_ratio})

        require(len(pair) == 6 and all(set(modes) == {'greedy','sample'}
                                        and modes['greedy'] == modes['sample'] for modes in pair.values()),
                'Six matched prompt pairs not established')
        modes = {}
        all_trigrams = []
        all_ratios = []
        for mode, vals in per_mode.items():
            require(len(vals) == 6, f'Expected six {mode} cases')
            rr = [v[0] for v in vals]; uu = [v[1] for v in vals]
            modes[mode] = {'case_count': 6,
                           'mean_repeated_trigram_fraction': statistics.mean(rr),
                           'mean_unique_token_ratio': statistics.mean(uu),
                           'cases_gt_30pct_repeated_trigrams': sum(v > 0.3 for v in rr)}
            all_trigrams.extend(rr)
            all_ratios.extend(uu)
        same(statistics.mean(all_trigrams), result['mean_repeated_trigram_fraction'], 'Summary mean trigrams')
        same(statistics.mean(all_ratios), result['mean_unique_token_ratio'], 'Summary mean unique ratio')
        same(result['mean_generated_tokens'], 48, 'Summary mean token count')
        require(result['eos_count'] == 0, 'Summary eos count')
        require(sum(c['generated_tokens'] for c in output_cases) == 576, 'Total token count')

        # Preserve unedited rendered continuations; the readout is audited as a separate source file.
        md = z.read('fixed/M94_READOUT.md').decode('utf-8').replace('\r\n', '\n')
        for c in output_cases:
            case = by_summary[c['case_id']]
            require(f'### {c["case_id"]} — ' in md, f'Missing readout heading: {c["case_id"]}')
            require(case['continuation_text'] in md, f'Readout continuation mismatch: {c["case_id"]}')

        return {
            'status': 'PASS_FOR_SUPPLIED_M94_ARTIFACTS',
            'archive_sha256': digest_file(path),
            'members_crc_test': 'PASS',
            'm94_run_identity_sha256': run_id,
            'checkpoint_sha256_attested_in_manifest': manifest['checkpoint_sha256_verified_m91'],
            'checkpoint_bytes_rehashed_here': False,
            'protocol_sha256_attested': manifest['m94_protocol_file_sha256'],
            'tokenizer_revision': manifest['tokenizer_revision'],
            'backend': manifest['backend'], 'precision': manifest['precision'],
            'generation_impl': manifest['generation_impl'],
            'total_prompts': 6, 'total_cases': len(output_cases),
            'total_generated_tokens': 576, 'eos_count': 0,
            'reported_execution_seconds': status['seconds_total'],
            'human_rating': result['human_rating'],
            'fused_parity': result['fused_parity'],
            'modes': modes,
            'cases': output_cases,
            'cross_checks': [
                'All 12 per-case JSONs match cases embedded in m94_results.json',
                'All 12 CSV rows match corresponding case texts, IDs, generation counts and reported metrics',
                'Per-case metrics independently recomputed from generated token IDs',
                'Six matched prompts across greedy and seeded sampling',
                'Status, run identity, protocol identity, backend, precision, EOS and sample counts internally consistent',
                'All unedited continuations are present in M94_READOUT.md'
            ],
            'limitations': [
                'No checkpoint was loaded; original generation/model forward was not rerun.',
                'The checkpoint SHA is inherited from historical local receipts, not rehashed in this audit.',
                'These 12 short, English-only continuations do not establish general factuality or language ability.',
                'Zero EOS in 48-token-capped continuations does not measure natural stopping behavior.',
                'Lower repeated-trigram rates are descriptive, not a causal measure of human coherence or accuracy.',
                'FP32 chunkwise evaluation is not known numerically equivalent to BF16/fused training backend.'
            ]
        }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    report = audit(args.archive)
    result = json.dumps(report, indent=2, ensure_ascii=False) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(result, encoding='utf-8')
    else:
        print(result)
    print('PASS: 12 case receipts and all token-level metrics verified')


if __name__ == '__main__':
    main()
